# op179089 算子当前版本

这是两个同形连续 FP32 张量的逐元素加法。支持 1D–8D，元素总数上限为 33,554,432。当前默认 Tile 为 4096 个元素。

- `op179089.asc` 为当前源码，可配合 `CMakeLists.txt` 和 `build.sh` 在 CANN 9.0 环境构建。
- `baseline/`、`next/` 和 `op179089.patch` 保留本地交接基线及补丁。交接基线校验和与当前云端工程不同，应用前应核对实际文件。
- `scripts/` 提供回归、性能采集、日志解析及文件校验脚本。`reports/local-validation.log` 记录本地复测。

## 构建和运行

载入 CANN 环境后执行。

```bash
NPU_ARCH=dav-2201 bash build.sh
./build/op179089 --shape 2x2x2x2x2x2x2x3
python3 scripts/run_npu_suite.py --binary build/op179089 --profile
```

## 验证状态

当前源码通过本地模拟回归，包含 25 组功能、11 组非法参数和 4 组形状与长度边界测试。

调整向量掩码前的候选版在 Atlas A3、CANN 9.0.0 上通过同一套功能和参数回归。16M 元素测得 182.018 µs、1106.08 GB/s，32M 元素测得 370.943 µs、1085.49 GB/s。带宽按两读一写的逻辑字节数计算。

当前版在 A3 上针对 1、7、9 元素的插桩内存检查通过。8193 和 40961 元素仍有 UB 访存报告，完整真机验收尚未通过。
